/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appCafyd2.BusinessLogicLayer.Models;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author alumno
 */
public class Seguimiento {
    public ArrayList<Entreno> registros;/*he puesto entreno en vez de formularioentreno porque he 
    pensado que como la variable que determina si ha terminado el entreno es el boolean de Enteno, creo que tenia sentido meter entreno. Porque como tal
    todosCompletados era la pregunra que haciamos en el formulario pero que era un poco sinmas no haciamos nada con esa info (creo recordar que dijimos eso)*/
    public Integer diasTotales;
    public ArrayList<Integer> diasVerdes;//para saber en concreto qué dias poner en verde
    public ArrayList<Integer> diasRojos;

    public Seguimiento() {
        this.registros = new ArrayList<>();
        this.diasTotales = 0;
        this.diasRojos =new ArrayList<>();
        this.diasVerdes=new ArrayList<>();
    }
    
    public void añadirEntreno(Entreno entreno){
        this.registros.add(entreno);
    }
    
    //PRIVADOS PORQUE ESTAS FUNCIONES NO INTERESA QUE LAS TOQUE NADIE MAS QUE LA FUNCION COMPROBARREGISTRO
    private void añadirVerde(LocalDate fecha){
        this.diasVerdes.add(fecha.getDayOfMonth());
    }
    
    private void añadirRojo(LocalDate fecha){
        this.diasRojos.add(fecha.getDayOfMonth());
    }
    
    public void comprobarRegistro(Entreno entreno){
        if (entreno.completado.equals(true)){
            añadirVerde(entreno.fecha);
        }
        else{
            añadirRojo(entreno.fecha);
        }
    }
    
    public Integer getDiasTotales(){
        int total = 0;
        for (int num : this.diasVerdes) {
            total += num;
        }
        for (int num : this.diasRojos) {
            total += num;
        }
        return total;
    }
    
}
