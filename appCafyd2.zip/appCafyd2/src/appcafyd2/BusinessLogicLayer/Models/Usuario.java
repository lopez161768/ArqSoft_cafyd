/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appCafyd2.BusinessLogicLayer.Models;

/**
 *
 * @author alumno
 */
public class Usuario {
    public String nombreUsuario;
    public String nombre;
    public String apellido;
    public Integer edad;
    public eCategory sexo;
    public Boolean calorias;
    public Integer racha;
    //public String foto; PARA CUANDO HAYA FOTO DE PERFIL

    public Usuario(String nombreUsuario, String nombre, String apellido, Integer edad, eCategory sexo, Boolean calorias) {
        this.nombreUsuario = nombreUsuario;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.sexo = sexo;
        this.calorias = calorias;
        this.racha = 0;
    }
    
    public void modificarNombreUsuario(String nuevoNombreUsuario){
        this.nombreUsuario = nuevoNombreUsuario;
    }
    
    public void modificarNombre(String nuevoNombre){
        this.nombre = nuevoNombre;
    }
    
    public void modificarApellido(String nuevoApellido){
        this.apellido = nuevoApellido;
    }
    
    public void modificarEdad(Integer nuevaEdad){
        this.edad = nuevaEdad;
    }
    
    public void modificarCalorias(Boolean nuevasCalorias){
        this.calorias = nuevasCalorias;
    }
    
    public void aumentarRacha(){
        this.racha = this.racha+1;
    }
    
    public void resetearRacha(){
        this.racha =0;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public Integer getEdad() {
        return edad;
    }

    public eCategory getSexo() {
        return sexo;
    }

    public Boolean getCalorias() {
        return calorias;
    }

    public Integer getRacha() {
        return racha;
    }
    
    /*public void cambiarFoto(String nuevaFoto){
        this.foto = nuevaFoto;
    }*/
}
