/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appCafyd2.BusinessLogicLayer.Models;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author alumno
 */
public class Entreno {
    public LocalDate fecha;
    public ArrayList<Ejercicio> ejercicios;
    public Boolean completado; //cuando saca la foto se completa el entreno

    public Entreno(LocalDate fecha) {
        this.fecha = fecha;
        this.ejercicios = new ArrayList<>();
        this.completado = false;
    }

    public void completar(){
        this.completado = true;
    }
    
    public void añadirEjercicio(Ejercicio ejercicio){
        this.ejercicios.add(ejercicio);
    }
    public LocalDate getFecha() {
        return fecha;
    }

    public Integer getEjercicios() {
        return ejercicios.size();
    }

    public Boolean getCompletado() {
        return completado;
    }
}
