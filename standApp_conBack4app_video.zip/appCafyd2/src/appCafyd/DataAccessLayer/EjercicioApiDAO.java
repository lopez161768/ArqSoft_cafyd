/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appCafyd.DataAccessLayer;

import appCafyd.BusinessLogicLayer.Models.Ejercicio;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.util.ArrayList;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class EjercicioApiDAO {

    private final String APPLICATION_ID = "efLmzg1LvgF58oqKQ6s0Nw0GizH2ssgul4z8AMUl";
    private final String REST_API_KEY = "ygnqEDUypcFGRm0pRrY8NGjOwgV462OGaBluopie";

    public ArrayList<Ejercicio> listarPorEntrenoId(String entrenoId) {
        ArrayList<Ejercicio> lista = new ArrayList<>();
        try {
            HttpUrl url = new HttpUrl.Builder()
                    .scheme("https")
                    .host("parseapi.back4app.com")
                    .addPathSegment("classes")
                    .addPathSegment("Ejercicio")
                    .addQueryParameter("where", "{\"entrenoId\":\"" + entrenoId + "\"}")
                    .build();

            System.out.println("DEBUG URL: " + url);

            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .get()
                    .build();

            OkHttpClient client = new OkHttpClient();
            Response response = client.newCall(request).execute();
            String bodyStr = response.body().string();

            System.out.println("DEBUG codigo: " + response.code());
            System.out.println("DEBUG respuesta: " + bodyStr);

            if (response.code() == 200) {
                JsonObject body = new Gson().fromJson(bodyStr, JsonObject.class);
                JsonArray results = body.getAsJsonArray("results");
                System.out.println("DEBUG ejercicios encontrados: " + results.size());
                for (JsonElement el : results) {
                    JsonObject obj = el.getAsJsonObject();
                    String nombre = obj.has("nombreEj") ? obj.get("nombreEj").getAsString() : "";
                    String video = obj.has("descripcionIm") ? obj.get("descripcionIm").getAsString() : "";
                    int series = obj.has("series") ? obj.get("series").getAsInt() : 3;
                    int reps = obj.has("repeticiones") ? obj.get("repeticiones").getAsInt() : 10;
                    String fallo = obj.has("fallosComunes") ? obj.get("fallosComunes").getAsString() : "";
                    System.out.println("DEBUG ejercicio: " + nombre + " | video: " + video);
                    Ejercicio ej = new Ejercicio(nombre, video, series, reps, 60, 50);
                    if (!fallo.isEmpty()) {
                        ej.añadirFallo(fallo);
                    }
                    lista.add(ej);
                }
            }
        } catch (IOException e) {
            System.out.println("Error cargando ejercicios: " + e.getMessage());
        }
        return lista;
    }
}
