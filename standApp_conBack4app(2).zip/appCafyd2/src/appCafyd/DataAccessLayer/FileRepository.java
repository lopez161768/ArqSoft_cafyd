package appCafyd.DataAccessLayer;

import com.google.gson.Gson;
import java.io.File;
import java.nio.file.Files;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Sube ficheros genéricos (vídeos .mp4, etc.) a la Files API de Back4App
 * usando multipart/form-data.
 * Devuelve un FileResource con la URL pública, o null si falla.
 */
public class FileRepository {

    private final String API_URL        = "https://parseapi.back4app.com/files";
    private final String APPLICATION_ID = "efLmzg1LvgF58oqKQ6s0Nw0GizH2ssgul4z8AMUl";
    private final String REST_API_KEY   = "ygnqEDUypcFGRm0pRrY8NGjOwgV462OGaBluopie";

    /**
     * @param file        Fichero a subir (.mp4, .txt, etc.)
     * @param nameUpload  Nombre con el que quedará en Back4App (ej: "sentadilla.mp4")
     * @return FileResource con url y name, o null si hay error
     */
    public FileResource upload(File file, String nameUpload) {
        FileResource result = null;
        try {
            OkHttpClient client = new OkHttpClient();

            byte[] byteArray = Files.readAllBytes(file.toPath());

            // Detectar content-type básico por extensión
            String contentType = "application/octet-stream";
            String lower = file.getName().toLowerCase();
            if (lower.endsWith(".mp4"))  contentType = "video/mp4";
            else if (lower.endsWith(".mov")) contentType = "video/quicktime";
            else if (lower.endsWith(".avi")) contentType = "video/x-msvideo";

            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart(
                            "file",
                            file.getName(),
                            RequestBody.create(MediaType.parse(contentType), byteArray))
                    .build();

            Request request = new Request.Builder()
                    .url(API_URL + "/" + nameUpload)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .post(requestBody)
                    .build();

            Response response = client.newCall(request).execute();

            if (response.code() == 201) {
                result = new Gson().fromJson(response.body().string(), FileResource.class);
                System.out.println("Fichero subido: " + result.url);
            } else {
                System.out.println("Error subiendo fichero (" + response.code() + "): " + response.body().string());
            }
        } catch (Exception ex) {
            System.out.println("Error FileRepository: " + ex.getMessage());
        }
        return result;
    }
}
