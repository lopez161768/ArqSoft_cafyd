package appCafyd.DataAccessLayer;

/**
 * Respuesta de Back4App al subir un fichero.
 * Contiene la URL pública y el nombre interno asignado.
 */
public class FileResource {
    public String url;
    public String name;
}
