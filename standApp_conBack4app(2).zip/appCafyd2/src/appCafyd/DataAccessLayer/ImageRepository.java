package appCafyd.DataAccessLayer;

import com.google.gson.Gson;
import java.io.File;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Sube imágenes JPEG a la Files API de Back4App.
 * Devuelve un FileResource con la URL pública y el nombre asignado,
 * o null si falla.
 */
public class ImageRepository {

    private final String API_URL       = "https://parseapi.back4app.com/files";
    private final String APPLICATION_ID = "efLmzg1LvgF58oqKQ6s0Nw0GizH2ssgul4z8AMUl";
    private final String REST_API_KEY   = "ygnqEDUypcFGRm0pRrY8NGjOwgV462OGaBluopie";

    /**
     * @param imageFile   Fichero .jpg / .png a subir
     * @param nameUpload  Nombre con el que quedará en Back4App (ej: "foto_dia1.jpg")
     * @return FileResource con url y name, o null si hay error
     */
    public FileResource upload(File imageFile, String nameUpload) {
        FileResource result = null;
        try {
            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder()
                    .url(API_URL + "/" + nameUpload)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .post(RequestBody.create(MediaType.parse("image/jpeg"), imageFile))
                    .build();

            Response response = client.newCall(request).execute();

            if (response.code() == 201) {
                result = new Gson().fromJson(response.body().string(), FileResource.class);
                System.out.println("Imagen subida: " + result.url);
            } else {
                System.out.println("Error subiendo imagen (" + response.code() + "): " + response.body().string());
            }
        } catch (Exception ex) {
            System.out.println("Error ImageRepository: " + ex.getMessage());
        }
        return result;
    }
}
