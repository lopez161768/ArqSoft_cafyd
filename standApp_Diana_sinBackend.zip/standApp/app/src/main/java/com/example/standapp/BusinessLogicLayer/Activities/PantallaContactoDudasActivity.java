package com.example.standapp.BusinessLogicLayer.Activities;

import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.standapp.R;

public class PantallaContactoDudasActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_contacto_dudas);

        Button buttonCerrar = findViewById(R.id.buttonCerrar);
        buttonCerrar.setOnClickListener(v -> finish());
    }
}