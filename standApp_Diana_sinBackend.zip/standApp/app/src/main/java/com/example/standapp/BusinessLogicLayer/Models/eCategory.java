/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.standapp.BusinessLogicLayer.Models;

public enum eCategory {
    Hombre,
    Mujer
}
