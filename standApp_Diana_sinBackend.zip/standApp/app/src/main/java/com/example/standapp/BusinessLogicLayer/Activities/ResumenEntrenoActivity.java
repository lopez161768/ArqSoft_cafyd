package com.example.standapp.BusinessLogicLayer.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.standapp.BusinessLogicLayer.Adapters.EjercicioAdapter;
import com.example.standapp.BusinessLogicLayer.Models.Entreno;
import com.example.standapp.DataAccessLayer.EntrenoDAO;
import com.example.standapp.R;

public class ResumenEntrenoActivity extends AppCompatActivity {

    private RecyclerView recyclerEjercicios;
    private Button botonEmpezar;
    private Entreno entrenoHoy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_resumen_entreno);

        // conectar vistas
        recyclerEjercicios = findViewById(R.id.recyclerView);
        botonEmpezar = findViewById(R.id.buttonStart);

        // obtener datos del DAO
        entrenoHoy = EntrenoDAO.getInstance().getEntrenoHoy();

        // por si no hay datos
        if(entrenoHoy == null) return;

        // configurar recycler
        EjercicioAdapter adapter = new EjercicioAdapter(entrenoHoy.getListaEjercicios());

        recyclerEjercicios.setLayoutManager(new LinearLayoutManager(this));
        recyclerEjercicios.setAdapter(adapter);

        // botón empezar --> primer ejercicio
        botonEmpezar.setOnClickListener(v -> {
            Intent intent = new Intent(ResumenEntrenoActivity.this, PantallaEjercicioActivity.class);

            intent.putExtra("indice", 0);

            startActivity(intent);
        });

    }
}