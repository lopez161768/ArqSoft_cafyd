package com.example.standapp.DataAccessLayer;

import com.example.standapp.BusinessLogicLayer.Models.Ejercicio;
import com.example.standapp.BusinessLogicLayer.Models.Entreno;

import java.util.ArrayList;

public class EntrenoDAO {
    // -------- Singleton --------
    private static EntrenoDAO instancia;

    public static EntrenoDAO getInstance() {
        if (instancia == null) {
            instancia = new EntrenoDAO();
            instancia.cargarDatosDePrueba(); // carga ejercicios de ejemplo
        }
        return instancia;
    }

    private EntrenoDAO() {} // constructor privado

    private ArrayList<Entreno> entrenosBD = new ArrayList<>();

    // Guardar un entreno
    public void guardar(Entreno entreno) {
        // Si ya existe uno con la misma fecha lo reemplaza
        for (int i = 0; i < entrenosBD.size(); i++) {
            if (entrenosBD.get(i).fecha.equals(entreno.fecha)) {
                entrenosBD.set(i, entreno);
                return;
            }
        }
        entrenosBD.add(entreno);
    }

    // Buscar por fecha (String "2026-04-27")
    public Entreno buscarPorFecha(String fecha) {
        for (Entreno entreno : entrenosBD) {
            if (entreno.fecha.equals(fecha)) {
                return entreno;
            }
        }
        return null;
    }

    // Obtener el entreno de hoy
    public Entreno getEntrenoHoy() {
        if (entrenosBD.isEmpty()) return null;
        return entrenosBD.get(0); // el primero es el de hoy
    }

    // Listar todos
    public ArrayList<Entreno> listarTodos() {
        return entrenosBD;
    }

    // -------- Datos de prueba --------
    private void cargarDatosDePrueba() {
        Entreno entreno = new Entreno("2026-05-04", 1);
        cargarEjerciciosDelDia(entreno, 1);
        entrenosBD.add(entreno);
    }

    private void cargarEjerciciosDelDia(Entreno entreno, int diaReto) {
        switch (diaReto) {
            case 1:
                entreno.añadirEjercicio(ej("Sentadillas", "sentadilla.mp4", 3, 10, "Rodillas hacia adentro"));
                entreno.añadirEjercicio(ej("Flexiones", "flexiones.mp4", 3, 10, "Codos muy abiertos"));
                entreno.añadirEjercicio(ej("Plancha", "plancha.mp4", 3, 20, "Cadera arriba o abajo"));
                break;
            case 2:
                entreno.añadirEjercicio(ej("Zancadas", "zancada.mp4", 3, 10, "Pecho inclinado"));
                entreno.añadirEjercicio(ej("Fondos de triceps", "fondos.mp4", 3, 10, "Bajar poco"));
                entreno.añadirEjercicio(ej("Puente de gluteos", "puente.mp4", 3, 15, "No subir las caderas del todo"));
                break;
            case 3:
                entreno.añadirEjercicio(ej("Burpees", "burpees.mp4", 3, 8, "No extender bien arriba"));
                entreno.añadirEjercicio(ej("Mountain climbers", "mountain.mp4", 3, 20, "Caderas altas"));
                entreno.añadirEjercicio(ej("Gemelos", "gemelos.mp4", 3, 20, "No subir del todo"));
                break;
            case 4:
                entreno.añadirEjercicio(ej("Sentadilla sumo", "sumo.mp4", 4, 12, "Espalda encorvada"));
                entreno.añadirEjercicio(ej("Press de hombros", "hombros.mp4", 3, 10, "Arquear la espalda baja"));
                entreno.añadirEjercicio(ej("Abdominales", "abdominales.mp4", 3, 15, "Tirar del cuello"));
                break;
            case 5:
                entreno.añadirEjercicio(ej("Flexiones inclinadas", "flexInc.mp4", 3, 12, "Codos muy abiertos"));
                entreno.añadirEjercicio(ej("Sentadilla bulgara", "bulgara.mp4", 3, 10, "Rodilla delantera pasa el pie"));
                entreno.añadirEjercicio(ej("Plancha lateral", "planchaLat.mp4", 3, 20, "Cadera que cae"));
                break;
            default:
                int bloque = diaReto % 3;
                if (bloque == 0) {
                    entreno.añadirEjercicio(ej("Sentadillas", "sentadilla.mp4", 3 + diaReto / 10, 10 + diaReto / 5, "Rodillas hacia adentro"));
                    entreno.añadirEjercicio(ej("Flexiones", "flexiones.mp4", 3 + diaReto / 10, 10 + diaReto / 5, "Codos muy abiertos"));
                    entreno.añadirEjercicio(ej("Plancha", "plancha.mp4", 3, 20 + diaReto, "Cadera"));
                } else if (bloque == 1) {
                    entreno.añadirEjercicio(ej("Zancadas", "zancada.mp4", 3 + diaReto / 10, 10 + diaReto / 5, "Pecho inclinado"));
                    entreno.añadirEjercicio(ej("Burpees", "burpees.mp4", 3, 8 + diaReto / 5, "No extender"));
                    entreno.añadirEjercicio(ej("Puente gluteos", "puente.mp4", 3, 15 + diaReto / 5, "No subir del todo"));
                } else {
                    entreno.añadirEjercicio(ej("Fondos", "fondos.mp4", 3 + diaReto / 10, 10 + diaReto / 5, "Bajar poco"));
                    entreno.añadirEjercicio(ej("Mountain climb", "mountain.mp4", 3, 20 + diaReto, "Caderas altas"));
                    entreno.añadirEjercicio(ej("Abdominales", "abds.mp4", 3, 15 + diaReto / 5, "Tirar del cuello"));
                }
                break;
        }
    }

    private Ejercicio ej(String nombre, String video, int series, int reps, String fallo) {
        return ej(nombre, video, series, reps, fallo, 60, 50);
    }

    private Ejercicio ej(String nombre, String video, int series, int reps, String fallo, int descanso, int calorias) {
        Ejercicio e = new Ejercicio(nombre, video, series, reps, descanso, calorias);
        e.anadirFallo(fallo);
        return e;
    }
}
