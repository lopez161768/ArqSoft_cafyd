package com.example.standapp.BusinessLogicLayer.Activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.standapp.BusinessLogicLayer.Models.Ejercicio;
import com.example.standapp.BusinessLogicLayer.Models.Entreno;
import com.example.standapp.DataAccessLayer.EntrenoDAO;
import com.example.standapp.R;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class PantallaEjercicioActivity extends AppCompatActivity {

    private ImageView imageEjercicio;
    private TextView textNombre;
    private TextView textSeriesRepes;
    private TextView textSerieActual;
    private TextView textFallos;
    private Button buttonDudas;
    private Button buttonSiguiente;

    private Entreno entrenoHoy;
    private int indiceActual;

    private String rutaFoto; // ruta donde se guarda la foto0

    // Lanzador de la cámara
    private final ActivityResultLauncher<Intent> cameraLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK) {
                            Toast.makeText(this, "rutaFoto vale: " + rutaFoto, Toast.LENGTH_LONG).show();

                            if (rutaFoto != null) {
                                entrenoHoy.foto = rutaFoto;
                                entrenoHoy.completar();
                                EntrenoDAO.getInstance().guardar(entrenoHoy);
                                Intent intent = new Intent(this, FormularioActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                // ✅ Si rutaFoto es null, ir al formulario igualmente
                                entrenoHoy.foto = "sin_foto";
                                entrenoHoy.completar();
                                EntrenoDAO.getInstance().guardar(entrenoHoy);
                                Intent intent = new Intent(this, FormularioActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_ejercicio);

        // conectar vistas
        imageEjercicio = findViewById(R.id.imageEjercicio);
        textNombre = findViewById(R.id.textNombre);
        textSeriesRepes = findViewById(R.id.textSeriesReps);
        textSerieActual = findViewById(R.id.textSerieActual);
        textFallos = findViewById(R.id.textFallos);
        buttonDudas = findViewById(R.id.buttonDudas);
        buttonSiguiente = findViewById(R.id.buttonSiguiente);

        // obtener datos
        entrenoHoy = EntrenoDAO.getInstance().getEntrenoHoy();
        indiceActual = getIntent().getIntExtra("indice", 0);

        // mostrar ejercicio actual
        mostrarEjercicio(indiceActual);

        // botón dudas
        buttonDudas.setOnClickListener(v -> {
            Intent intent = new Intent(this, PantallaContactoDudasActivity.class);
            startActivity(intent);
        });

        // botón siguiente
        buttonSiguiente.setOnClickListener(v -> {
            int siguienteIndice = indiceActual + 1;
            int totalEjercicios = entrenoHoy.getNumEjercicios();

            if (siguienteIndice < totalEjercicios) {
                //Intent intent = new Intent(this, PantallaEjercicioActivity.class);
                //intent.putExtra("indice", siguienteIndice);
                indiceActual = siguienteIndice;
                mostrarEjercicio(indiceActual);
                //startActivity(intent);
            } else {
                // último ejercicio --> cámara
                dispatchTakePictureIntent();
            }
        });

    }

    private void mostrarEjercicio(int indice) {
        Ejercicio ejercicio = entrenoHoy.getListaEjercicios().get(indice);

        // imagen
        imageEjercicio.setImageResource(R.drawable.ic_launcher_background);

        // nombrw
        textNombre.setText(ejercicio.getNombreEj());

        // series x repes
        textSeriesRepes.setText(ejercicio.getSeries() + "series x " + ejercicio.getRepeticiones() + "repeticiones");

        // serie actual
        textSerieActual.setText("Ejercicio " + (indice + 1) + " / " + entrenoHoy.getNumEjercicios());

        // fallos comunes
        ArrayList<String> fallos = ejercicio.getFallosComunes();
        if (fallos != null && !fallos.isEmpty()){
            StringBuilder sb = new StringBuilder("Fallos comunes: \n");
            for (String fallo : fallos){
                sb.append("-->").append(fallo).append("\n");
            }
            textFallos.setText(sb.toString());
        }
        else{
            textFallos.setText("No hay fallos comunes registrados");
        }

    }

    // Metodo para abrir la cámara y guardar la foto
    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        File photoFile = null;
        try {
            photoFile = createImageFile();
            Toast.makeText(this, "Archivo creado: " + rutaFoto, Toast.LENGTH_SHORT).show();
        } catch (IOException ex) {
            ex.printStackTrace();
            Toast.makeText(this, "ERROR al crear archivo: " + ex.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }

        if (photoFile != null) {
            try {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.example.standapp.fileprovider",
                        photoFile);
                Toast.makeText(this, "URI creada, abriendo cámara...", Toast.LENGTH_SHORT).show();
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                cameraLauncher.launch(takePictureIntent);
            } catch (Exception e) {
                Toast.makeText(this, "ERROR FileProvider: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "photoFile es null", Toast.LENGTH_SHORT).show();
        }
    }

    // Crear un archivo único para la foto
    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";

        // Intentar primero caché externa, si no usar caché interna
        File storageDir = getExternalCacheDir();
        if (storageDir == null) {
            storageDir = getCacheDir(); // fallback a caché interna
        }

        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );

        rutaFoto = image.getAbsolutePath();
        return image;
    }
}
