/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.standapp.BusinessLogicLayer.Models;

import java.time.LocalDate;
import java.util.ArrayList;

public class Entreno {
    public String fecha; // CAMBIAR FECHA A STRING!!!
    public ArrayList<Ejercicio> ejercicios;
    public Boolean completado; //cuando saca la foto se completa el entreno
    public String foto;
    public Integer dificultad; 
    public Integer diaReto;
    public Integer caloriasQuemadas; // suma de calorias de todos los ejercicios
    
    public Entreno(String fecha, Integer diaReto) {
        this.fecha = fecha;
        this.ejercicios = new ArrayList<>();
        this.completado = false;
        this.foto = "";
        this.dificultad = 0;
        this.diaReto = diaReto;
    }

    public void completar(){
        this.completado = true;
    }
    
    public void añadirEjercicio(Ejercicio ejercicio){
        this.ejercicios.add(ejercicio);
    }
    
    public Integer getNumEjercicios() {
        return ejercicios.size();
    }

    public Boolean isCompletado() {
        return completado;
    }

    public ArrayList<Ejercicio> getListaEjercicios() {
        return ejercicios;
    }
     
    public void calcularCalorias() {//Suma las calorias de todos los ejercicios del entreno
        int total = 0;
        for (Ejercicio ej : ejercicios) {
            if (ej.caloriasEj != null) total += ej.caloriasEj;
        }
        this.caloriasQuemadas = total;
    }
    
}
