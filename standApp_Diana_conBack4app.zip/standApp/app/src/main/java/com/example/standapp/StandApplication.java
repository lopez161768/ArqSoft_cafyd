package com.example.standapp;

import android.app.Application;
import android.os.StrictMode;

import com.example.standapp.DataAccessLayer.EntrenoApiDAO;

public class StandApplication extends Application {

    private EntrenoApiDAO entrenoApiDAO;

    @Override
    public void onCreate() {
        super.onCreate();

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        this.entrenoApiDAO = new EntrenoApiDAO();
    }

    public EntrenoApiDAO getEntrenoApiDAO() {
        return entrenoApiDAO;
    }
}
