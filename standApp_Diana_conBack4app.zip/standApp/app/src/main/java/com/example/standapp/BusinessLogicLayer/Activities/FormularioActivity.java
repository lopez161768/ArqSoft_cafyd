package com.example.standapp.BusinessLogicLayer.Activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.example.standapp.BusinessLogicLayer.Models.Entreno;
import com.example.standapp.BusinessLogicLayer.Models.FormularioEntreno;
import com.example.standapp.DataAccessLayer.EntrenoApiDAO;
import com.example.standapp.DataAccessLayer.EntrenoDAO;
import com.example.standapp.R;
import com.example.standapp.StandApplication;

import java.io.File;

public class FormularioActivity extends AppCompatActivity {

    private RadioGroup radioGroupDificultad;
    private RadioGroup radioGroupCompletados;
    private Button buttonTerminar;

    // para bacj4app
    private EntrenoApiDAO entrenoApiDAO;
    private Entreno entrenoHoy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);

        radioGroupDificultad = findViewById(R.id.radioGroupDificultad);
        radioGroupCompletados = findViewById(R.id.radioGroupCompletados);
        buttonTerminar = findViewById(R.id.buttonTerminar);

        // obtener DAO de back4app
        entrenoApiDAO = ((StandApplication) getApplicationContext()).getEntrenoApiDAO();
        entrenoHoy = EntrenoDAO.getInstance().getEntrenoHoy();

        // Mostrar la foto tomada
        ImageView imageFoto = findViewById(R.id.imageFotoEntreno);
        if (entrenoHoy != null && entrenoHoy.foto != null && !entrenoHoy.foto.isEmpty()) {

            if (entrenoHoy.foto.startsWith("http")) {
                // Es una URL de Back4App --> cargar con Glide
                Glide.with(this).load(entrenoHoy.foto).into(imageFoto);
            } else {
                File imgFile = new File(entrenoHoy.foto);
                if (imgFile.exists()) {
                    Bitmap bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                    imageFoto.setImageBitmap(bitmap);
                }
            }
        }

        buttonTerminar.setOnClickListener(v -> {
            // recoger la dificultad selec
            int dif = 0;
            int idDif = radioGroupDificultad.getCheckedRadioButtonId();

            if(idDif == R.id.radio1) dif = 1;
            else if(idDif == R.id.radio2) dif = 2;
            else if(idDif == R.id.radio3) dif = 3;
            else if(idDif == R.id.radio4) dif = 4;
            else if(idDif == R.id.radio5) dif = 5;

            // recoger ej completados
            boolean todosComp = false;
            int idComp = radioGroupCompletados.getCheckedRadioButtonId();
            if(idComp == R.id.radioSi) todosComp = true;
            else if(idComp == R.id.radioNo) todosComp = false;

            // validar que ha respondido las 2 preguntas
            if(idDif == -1 || idComp == -1){
                Toast.makeText(this, "Por favor responde todas las preguntas", Toast.LENGTH_SHORT).show();
                return;
            }

            // crear y guardar el formulario
            if(entrenoHoy != null){
                FormularioEntreno formulario = new FormularioEntreno(entrenoHoy, entrenoHoy.foto);
                formulario.registrarDificultad(dif);
                formulario.registrarCompletados(todosComp);

                // actualizar datos entreno
                entrenoHoy.dificultad = dif;
                entrenoHoy.completado = true;

                // guardar en bacck4app
                entrenoApiDAO.guardar(entrenoHoy);
            }

            // volver a la pantalla resumen entreno
            Intent intent = new Intent(this, ResumenEntrenoActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });
    }
}