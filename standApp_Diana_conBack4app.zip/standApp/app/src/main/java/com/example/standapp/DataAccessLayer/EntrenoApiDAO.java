package com.example.standapp.DataAccessLayer;

import com.example.standapp.BusinessLogicLayer.Models.Ejercicio;
import com.example.standapp.BusinessLogicLayer.Models.Entreno;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class EntrenoApiDAO {

    private final String APPLICATION_ID = "efLmzg1LvgF58oqKQ6s0Nw0GizH2ssgul4z8AMUl";
    private final String REST_API_KEY = "ygnqEDUypcFGRm0pRrY8NGjOwgV462OGaBluopie";
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();

    // clase interna para mapear JSON de Entreno
    private class EntrenoJson {
        public String objectId;
        public String usuarioId;
        public String fecha;
        public Integer diaReto;
        public Boolean completado;
        public String foto;
        public Integer dificultad;
        public Integer caloriasQuemadas;
    }

    // obtener entreno por dia reto
    public Entreno buscarPorDiaReto(int diaReto){
        try{
            HttpUrl url = new HttpUrl.Builder()
                    .scheme("https")
                    .host("parseapi.back4app.com")
                    .addPathSegment("classes")
                    .addPathSegment("Entreno")
                    .addQueryParameter("where", "{\"diaReto\":" + diaReto + "}")
                    .build();

            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if(response.code() == 200){
                JsonObject body = gson.fromJson(response.body().string(), JsonObject.class);
                JsonArray results = body.getAsJsonArray("results");

                if(results.size() > 0){
                    EntrenoJson j = gson.fromJson(results.get(0), EntrenoJson.class);
                    Entreno e = new Entreno(j.fecha, j.diaReto);
                    e.objectId = j.objectId;
                    e.completado = j.completado;
                    e.foto = j.foto != null ? j.foto : "";
                    e.dificultad = j.dificultad != null ? j.dificultad : 0;
                    return e;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    // obtener ejercicios de un entreno por objectId
    public ArrayList<Ejercicio>  listarEjerciciosPorEntrenoId(String entrenoId){
        ArrayList<Ejercicio> lista = new ArrayList<>();
        try{
            HttpUrl url = new HttpUrl.Builder()
                    .scheme("https")
                    .host("parseapi.back4app.com")
                    .addPathSegment("classes")
                    .addPathSegment("Ejercicio")
                    .addQueryParameter("where", "{\"entrenoId\":\"" + entrenoId + "\"}")
                    .build();

            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                JsonObject body = gson.fromJson(response.body().string(), JsonObject.class);
                JsonArray results = body.getAsJsonArray("results");
                for (JsonElement el : results) {
                    JsonObject obj = el.getAsJsonObject();
                    String nombre = obj.has("nombreEj") ? obj.get("nombreEj").getAsString() : "";
                    String video = obj.has("descripcionIm") ? obj.get("descripcionIm").getAsString() : "";
                    int series = obj.has("series") ? obj.get("series").getAsInt() : 3;
                    int reps = obj.has("repeticiones") ? obj.get("repeticiones").getAsInt() : 10;
                    String fallo = obj.has("fallosComunes") ? obj.get("fallosComunes").getAsString() : "";

                    Ejercicio ej = new Ejercicio(nombre, video, series, reps, 60, 50);
                    if (!fallo.isEmpty()) ej.anadirFallo(fallo);
                    lista.add(ej);
                }
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // guardar entreno completo
    public void guardar(Entreno entreno){
        try {
            EntrenoJson j = new EntrenoJson();
            j.usuarioId = entreno.usuarioId;
            j.fecha = entreno.fecha;
            j.diaReto = entreno.diaReto;
            j.completado = entreno.completado;
            j.foto = entreno.foto;
            j.dificultad = entreno.dificultad;
            j.caloriasQuemadas = entreno.caloriasQuemadas;

            String json = gson.toJson(j);

            // Si ya tiene objectId --> actualizar (PUT), si no --> crear (POST)
            Request request;
            if (entreno.objectId != null && !entreno.objectId.isEmpty()) {
                request = new Request.Builder()
                        .url("https://parseapi.back4app.com/classes/Entreno/" + entreno.objectId)
                        .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                        .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                        .put(RequestBody.create(MediaType.get("application/json"), json))
                        .build();
            } else {
                request = new Request.Builder()
                        .url("https://parseapi.back4app.com/classes/Entreno")
                        .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                        .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                        .post(RequestBody.create(MediaType.get("application/json"), json))
                        .build();
            }

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                JsonObject result = gson.fromJson(response.body().string(), JsonObject.class);
                if (result.has("objectId")) {
                    entreno.objectId = result.get("objectId").getAsString();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Entreno buscarEntrenoHoyPorUsuario(String nombreUsuario) {
        try {
            String fechaHoy = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
            String whereQuery = "{\"usuarioId\":\"" + nombreUsuario + "\",\"fecha\":\"" + fechaHoy + "\"}";

            HttpUrl url = new HttpUrl.Builder()
                    .scheme("https")
                    .host("parseapi.back4app.com")
                    .addPathSegment("classes")
                    .addPathSegment("Entreno")
                    .addQueryParameter("where", whereQuery)
                    .build();

            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                JsonObject body = gson.fromJson(response.body().string(), JsonObject.class);
                JsonArray results = body.getAsJsonArray("results");
                if (results.size() > 0) {
                    EntrenoJson j = gson.fromJson(results.get(0), EntrenoJson.class);
                    Entreno e = new Entreno(j.fecha, j.diaReto);
                    e.objectId = j.objectId;
                    e.usuarioId = j.usuarioId;
                    e.completado = j.completado != null ? j.completado : false;
                    e.foto = j.foto != null ? j.foto : "";
                    e.dificultad = j.dificultad != null ? j.dificultad : 0;
                    return e;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    // para subir la foto a b4a
    public String subirFoto(String rutaLocal, String nombreUsuario) {
        try {
            File foto = new File(rutaLocal);
            String nombreArchivo = "foto_dia" + "_" + System.currentTimeMillis() + ".jpg";

            Request request = new Request.Builder()
                    .url("https://parseapi.back4app.com/files/" + nombreArchivo)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .addHeader("Content-Type", "image/jpeg")
                    .post(RequestBody.create(MediaType.get("image/jpeg"), foto))
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                JsonObject result = gson.fromJson(response.body().string(), JsonObject.class);
                return result.get("url").getAsString(); // URL pública de Back4App
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
