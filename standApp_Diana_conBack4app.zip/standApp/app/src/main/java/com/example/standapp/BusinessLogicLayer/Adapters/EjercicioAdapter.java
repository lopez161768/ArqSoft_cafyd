package com.example.standapp.BusinessLogicLayer.Adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.standapp.BusinessLogicLayer.Models.Ejercicio;
import com.example.standapp.R;

import java.util.ArrayList;
import java.util.List;

public class EjercicioAdapter extends RecyclerView.Adapter<EjercicioAdapter.ViewHolder>{
    private ArrayList<Ejercicio> lista;

    public EjercicioAdapter(ArrayList<Ejercicio> lista) {
        this.lista = lista;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        ImageView img;
        TextView nombre, seriesRepes;

        public ViewHolder(@NonNull View itemView){
            super(itemView);
            img = itemView.findViewById(R.id.imgEjercicio);
            nombre = itemView.findViewById(R.id.tvNombre);
            seriesRepes = itemView.findViewById(R.id.tvSeriesReps);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ejercicio, parent, false);
        return new ViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Ejercicio ej = lista.get(position);

        holder.nombre.setText(ej.nombreEj);
        holder.seriesRepes.setText(ej.series + "x" + ej.repeticiones);

        // cargar miniatura del vídeo de YouTube
        String videoUrl = ej.getDescripcionIm();
        if (videoUrl != null && !videoUrl.isEmpty()) {
            String videoId = extraerVideoId(videoUrl);
            if (videoId != null) {
                String thumbnailUrl = "https://img.youtube.com/vi/" + videoId + "/0.jpg";
                Glide.with(holder.itemView.getContext())
                        .load(thumbnailUrl)
                        .placeholder(R.mipmap.ic_launcher)
                        .into(holder.img);
            }
        }
    }

    private String extraerVideoId(String url) {
        try {
            if (url.contains("youtu.be/")) {
                return url.split("youtu.be/")[1].split("\\?")[0];
            } else if (url.contains("shorts/")) {
                return url.split("shorts/")[1].split("\\?")[0];
            } else if (url.contains("v=")) {
                return url.split("v=")[1].split("&")[0];
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }
}
