package com.example.standapp.BusinessLogicLayer.Activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.standapp.BusinessLogicLayer.Models.Ejercicio;
import com.example.standapp.BusinessLogicLayer.Models.Entreno;
import com.example.standapp.DataAccessLayer.EntrenoApiDAO;
import com.example.standapp.DataAccessLayer.EntrenoDAO;
import com.example.standapp.R;
import com.example.standapp.StandApplication;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class PantallaEjercicioActivity extends AppCompatActivity {

    //private ImageView imageEjercicio;
    // para qque fncione el video de youtube
    private WebView webViewEjercicio;
    private TextView textNombre;
    private TextView textSeriesRepes;
    private TextView textSerieActual;
    private TextView textFallos;
    private Button buttonDudas;
    private Button buttonSiguiente;

    private Entreno entrenoHoy;
    private int indiceActual;

    private String rutaFoto; // ruta donde se guarda la foto

    // lanzador de la cámara
    private final ActivityResultLauncher<Intent> cameraLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK) {
                            Toast.makeText(this, "rutaFoto vale: " + rutaFoto, Toast.LENGTH_LONG).show();

                            if (rutaFoto != null) {
                                EntrenoApiDAO entrenoApiDAO = ((StandApplication) getApplicationContext()).getEntrenoApiDAO();

                                // Subir foto a b4a obtener URL
                                String urlFoto = entrenoApiDAO.subirFoto(rutaFoto, entrenoHoy.usuarioId);

                                if (urlFoto != null) {
                                    entrenoHoy.foto = urlFoto; // guarda URL
                                } else {
                                    entrenoHoy.foto = rutaFoto;
                                }
                                entrenoHoy.completar();
                                EntrenoDAO.getInstance().guardar(entrenoHoy);
                                Intent intent = new Intent(this, FormularioActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                // si rutaFoto es null, ir al formulario igualmente
                                entrenoHoy.foto = "sin_foto";
                                entrenoHoy.completar();
                                EntrenoDAO.getInstance().guardar(entrenoHoy);
                                Intent intent = new Intent(this, FormularioActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_ejercicio);

        // conectar vistas
        //imageEjercicio = findViewById(R.id.imageEjercicio);
        // para que aparezca el video de youtube
        webViewEjercicio = findViewById(R.id.webViewEjercicio);
        webViewEjercicio.getSettings().setJavaScriptEnabled(true);
        webViewEjercicio.getSettings().setDomStorageEnabled(true);
        webViewEjercicio.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webViewEjercicio.getSettings().setUserAgentString(
                "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        );

        textNombre = findViewById(R.id.textNombre);
        textSeriesRepes = findViewById(R.id.textSeriesReps);
        textSerieActual = findViewById(R.id.textSerieActual);
        textFallos = findViewById(R.id.textFallos);
        buttonDudas = findViewById(R.id.buttonDudas);
        buttonSiguiente = findViewById(R.id.buttonSiguiente);

        // obtener datos
        entrenoHoy = EntrenoDAO.getInstance().getEntrenoHoy();
        indiceActual = getIntent().getIntExtra("indice", 0);

        // mostrar ejercicio actual
        mostrarEjercicio(indiceActual);

        // botón dudas
        buttonDudas.setOnClickListener(v -> {
            Intent intent = new Intent(this, PantallaContactoDudasActivity.class);
            startActivity(intent);
        });

        // botón siguiente
        buttonSiguiente.setOnClickListener(v -> {
            int siguienteIndice = indiceActual + 1;
            int totalEjercicios = entrenoHoy.getNumEjercicios();

            if (siguienteIndice < totalEjercicios) {
                //Intent intent = new Intent(this, PantallaEjercicioActivity.class);
                //intent.putExtra("indice", siguienteIndice);
                indiceActual = siguienteIndice;
                mostrarEjercicio(indiceActual);
                //startActivity(intent);
            } else {
                // último ejercicio --> cámara
                dispatchTakePictureIntent();
            }
        });

    }

    // para mostrar el video de youtube
    private String extraerVideoId(String url) {
        // Soporta: youtu.be/ID, youtube.com/watch?v=ID, youtube.com/shorts/ID
        try {
            if (url.contains("youtu.be/")) {
                String id = url.split("youtu.be/")[1];
                return id.split("\\?")[0];
            } else if (url.contains("shorts/")) {
                return url.split("shorts/")[1].split("\\?")[0];
            } else if (url.contains("v=")) {
                return url.split("v=")[1].split("&")[0];
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private void mostrarEjercicio(int indice) {
        Ejercicio ejercicio = entrenoHoy.getListaEjercicios().get(indice);

        // miniatura clicable en el WebView
        String videoUrl = ejercicio.getDescripcionIm();
        String videoId = extraerVideoId(videoUrl);

        if (videoId != null) {
            String thumbnailUrl = "https://img.youtube.com/vi/" + videoId + "/0.jpg";
            String html = "<!DOCTYPE html><html><body style='margin:0;padding:0;background:#000;'>" +
                    "<a href='" + videoUrl + "'>" +
                    "<img src='" + thumbnailUrl + "' style='width:100%;height:100%;object-fit:cover;'/>" +
                    "</a></body></html>";
            webViewEjercicio.setVisibility(android.view.View.VISIBLE);
            webViewEjercicio.setWebViewClient(new android.webkit.WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(android.webkit.WebView view, String url) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                    return true;
                }
            });
            webViewEjercicio.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
        } else {
            webViewEjercicio.setVisibility(android.view.View.GONE);
        }

        // nombre
        textNombre.setText(ejercicio.getNombreEj());

        // series x reps
        textSeriesRepes.setText(ejercicio.getSeries() + " series x " + ejercicio.getRepeticiones() + " repeticiones");

        // ejercicio actual / total
        textSerieActual.setText("Ejercicio " + (indice + 1) + " / " + entrenoHoy.getNumEjercicios());

        // fallos comunes
        ArrayList<String> fallos = ejercicio.getFallosComunes();
        if (fallos != null && !fallos.isEmpty()) {
            StringBuilder sb = new StringBuilder("Fallos comunes: \n");
            for (String fallo : fallos) {
                sb.append("-->").append(fallo).append("\n");
            }
            textFallos.setText(sb.toString());
        } else {
            textFallos.setText("No hay fallos comunes registrados");
        }
    }

    // Metodo para abrir la cámara y guardar la foto
    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        File photoFile = null;
        try {
            photoFile = createImageFile();
            Toast.makeText(this, "Archivo creado: " + rutaFoto, Toast.LENGTH_SHORT).show();
        } catch (IOException ex) {
            ex.printStackTrace();
            Toast.makeText(this, "ERROR al crear archivo: " + ex.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }

        if (photoFile != null) {
            try {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.example.standapp.fileprovider",
                        photoFile);
                Toast.makeText(this, "URI creada, abriendo cámara...", Toast.LENGTH_SHORT).show();
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                cameraLauncher.launch(takePictureIntent);
            } catch (Exception e) {
                Toast.makeText(this, "ERROR FileProvider: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "photoFile es null", Toast.LENGTH_SHORT).show();
        }
    }

    // crear un archivo único para la foto
    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";

        // intentar primero caché externa, si no usar caché interna
        File storageDir = getExternalCacheDir();
        if (storageDir == null) {
            storageDir = getCacheDir();
        }

        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );

        rutaFoto = image.getAbsolutePath();
        return image;
    }
}
