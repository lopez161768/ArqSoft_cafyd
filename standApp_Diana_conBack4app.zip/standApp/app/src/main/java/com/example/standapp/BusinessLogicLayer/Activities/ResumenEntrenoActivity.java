package com.example.standapp.BusinessLogicLayer.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.standapp.BusinessLogicLayer.Adapters.EjercicioAdapter;
import com.example.standapp.BusinessLogicLayer.Models.Ejercicio;
import com.example.standapp.BusinessLogicLayer.Models.Entreno;
import com.example.standapp.DataAccessLayer.EntrenoApiDAO;
import com.example.standapp.DataAccessLayer.EntrenoDAO;
import com.example.standapp.R;
import com.example.standapp.StandApplication;

import java.util.ArrayList;

public class ResumenEntrenoActivity extends AppCompatActivity {

    private RecyclerView recyclerEjercicios;
    private Button botonEmpezar;
    private Entreno entrenoHoy;
    private EntrenoApiDAO entrenoApiDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumen_entreno);

        recyclerEjercicios = findViewById(R.id.recyclerView);
        botonEmpezar = findViewById(R.id.buttonStart);

        entrenoApiDAO = ((StandApplication) getApplicationContext()).getEntrenoApiDAO();

        // lee nombreUsuario del login; usa "pepa" como valor de prueba si no hay sesión
        String nombreUsuario = getSharedPreferences("standapp", MODE_PRIVATE)
                .getString("nombreUsuario", "pepa");

        Toast.makeText(this, "nombreUsuario: " + nombreUsuario, Toast.LENGTH_LONG).show();

        entrenoHoy = entrenoApiDAO.buscarEntrenoHoyPorUsuario(nombreUsuario);

        Toast.makeText(this, "entrenoHoy: " + (entrenoHoy != null ? entrenoHoy.objectId : "NULL"), Toast.LENGTH_LONG).show();

        if (entrenoHoy == null) {
            Toast.makeText(this, "No se encontró el entreno de hoy", Toast.LENGTH_SHORT).show();
            return;
        }

        ArrayList<Ejercicio> ejercicios = entrenoApiDAO.listarEjerciciosPorEntrenoId(entrenoHoy.objectId);

        Toast.makeText(this, "ejercicios encontrados: " + ejercicios.size(), Toast.LENGTH_LONG).show();

        entrenoHoy.ejercicios = ejercicios;

        if (ejercicios.isEmpty()) {
            Toast.makeText(this, "No se encontraron ejercicios", Toast.LENGTH_SHORT).show();
            return;
        }

        EjercicioAdapter adapter = new EjercicioAdapter(entrenoHoy.getListaEjercicios());
        recyclerEjercicios.setLayoutManager(new LinearLayoutManager(this));
        recyclerEjercicios.setAdapter(adapter);

        botonEmpezar.setOnClickListener(v -> {
            EntrenoDAO.getInstance().guardar(entrenoHoy);
            Intent intent = new Intent(ResumenEntrenoActivity.this, PantallaEjercicioActivity.class);
            intent.putExtra("indice", 0);
            startActivity(intent);
        });

    }
}