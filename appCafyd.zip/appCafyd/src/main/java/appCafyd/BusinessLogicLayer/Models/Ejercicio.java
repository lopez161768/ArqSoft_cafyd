/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appCafyd.BusinessLogicLayer.Models;

/**
 *
 * @author alumno
 */
public class Ejercicio {
    public String nombreEj;
    public String descripcionIm;
    public String fallosComunes; // ESTO SE MODIFICARÁ MÁS ADAELANTE
    public Integer repeticiones;

    public Ejercicio(String nombreEj, String descripcionIm, String fallosComunes, Integer repeticiones) {
        this.nombreEj = nombreEj;
        this.descripcionIm = descripcionIm;
        this.fallosComunes = fallosComunes;
        this.repeticiones = repeticiones;
    }
    
    
}
