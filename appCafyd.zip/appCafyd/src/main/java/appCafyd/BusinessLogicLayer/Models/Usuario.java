/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appCafyd.BusinessLogicLayer.Models;

/**
 *
 * @author alumno
 */
public class Usuario {
    public String nombre;
    public String apellido;
    public String nombreUsuario;
    public Integer edad;
    public String sexo;
    public Boolean calorias;
    public Integer racha;

    public Usuario(String nombre, String apellido, String nombreUsuario, Integer edad, String sexo, Boolean calorias) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.nombreUsuario = nombreUsuario;
        this.edad = edad;
        this.sexo = sexo;
        this.calorias = calorias;
        this.racha = 0;
    }
    
    
    
}
