/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appCafyd.BusinessLogicLayer.Models;

import java.util.ArrayList;

/**
 *
 * @author alumno
 */
public class Seguimiento {
    
    private ArrayList<RegistroEntreno> registros;

    public Seguimiento(ArrayList<RegistroEntreno> registros) {
        this.registros = registros;
    }
    
    
}
