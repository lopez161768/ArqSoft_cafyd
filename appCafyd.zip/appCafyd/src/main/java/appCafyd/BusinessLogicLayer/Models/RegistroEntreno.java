/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appCafyd.BusinessLogicLayer.Models;

/**
 *
 * @author alumno
 */
public class RegistroEntreno {
    public Entreno entreno;
    public Integer dificultad;
    public Boolean ejCompletados;
    public String foto;

    public RegistroEntreno(Entreno entreno, Integer dificultad, Boolean ejCompletados, String foto) {
        this.entreno = entreno;
        this.dificultad = dificultad;
        this.ejCompletados = ejCompletados;
        this.foto = foto;
    }
    
    
    
}
