/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appCafyd.BusinessLogicLayer.Models;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author alumno
 */
public class Entreno {
    public LocalDate fecha;
    public ArrayList<Ejercicio> ejercicios;
    public Boolean completado;

    public Entreno(LocalDate fecha, ArrayList<Ejercicio> ejercicios) {
        this.fecha = fecha;
        this.ejercicios = ejercicios;
        this.completado = false;
    }
    
    
    
}
