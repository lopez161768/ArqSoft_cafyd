/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package appCafyd.DataAccessLayer;


import appCafyd.BusinessLogicLayer.Models.Usuario;
import appCafyd.BusinessLogicLayer.Models.eCategory;
import appCafyd.BusinessLogicLayer.Services.IUsuario;
import com.google.gson.*;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import okhttp3.*;


public class UsuarioApiDAO implements IUsuario {
    private final String API_URL = "https://parseapi.back4app.com/classes/Usuario";
    private final String APPLICATION_ID = "efLmzg1LvgF58oqKQ6s0Nw0GizH2ssgul4z8AMUl";
    private final String REST_API_KEY = "ygnqEDUypcFGRm0pRrY8NGjOwgV462OGaBluopie";


    // Clase interna para serializar/deserializar con Gson
    private class UsuarioJson {
        public String objectId;
        public String nombreUsuario;
        public String contrasena;
        public String nombre;
        public String apellido;
        public Integer edad;
        public String sexo;
        public Boolean calorias;
        public Integer racha;
        public String fechaRegistro;
    }

    private UsuarioJson toJson(Usuario u) {
        UsuarioJson j = new UsuarioJson();
        j.nombreUsuario = u.nombreUsuario;
        j.contrasena = u.getContrasena();
        j.nombre = u.nombre;
        j.apellido = u.apellido;
        j.edad = u.edad;
        j.sexo = u.sexo.name();
        j.calorias = u.calorias;
        j.racha = u.racha;
        j.fechaRegistro = u.fechaRegistro.toString();
        return j;
    }

    private Usuario fromJson(UsuarioJson j) {
        Usuario u = new Usuario(
            j.nombreUsuario,
            j.contrasena,
            j.nombre,
            j.apellido,
            j.edad,
            eCategory.valueOf(j.sexo),
            j.calorias
        );
        u.objectId = j.objectId;
        u.racha = j.racha;
        u.fechaRegistro = LocalDate.parse(j.fechaRegistro);
        return u;
    }

    @Override
    public void insertar(Usuario usuario) {
        Gson gson = new Gson();
        String json = gson.toJson(toJson(usuario));
        try {
            Request request = new Request.Builder()
                .url(API_URL)
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .post(RequestBody.create(MediaType.get("application/json"), json))
                .build();
            OkHttpClient client = new OkHttpClient();
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                UsuarioJson nuevo = gson.fromJson(response.body().string(), UsuarioJson.class);
                usuario.objectId = nuevo.objectId;
                System.out.println("Usuario insertado con objectId: " + usuario.objectId);
            }
        } catch (IOException e) {
            System.out.println("Error insertar usuario: " + e.getMessage());
        }
    }

    @Override
    public void actualizar(Usuario usuario) {
        if (usuario.objectId == null) return;
        Gson gson = new Gson();
        String json = gson.toJson(toJson(usuario));
        try {
            Request request = new Request.Builder()
                .url(API_URL + "/" + usuario.objectId)
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .put(RequestBody.create(MediaType.get("application/json"), json))
                .build();
            OkHttpClient client = new OkHttpClient();
            client.newCall(request).execute();
            System.out.println("Usuario actualizado: " + usuario.nombreUsuario);
        } catch (IOException e) {
            System.out.println("Error actualizar usuario: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(String nombreUsuario) {
        Usuario u = buscarPorUsername(nombreUsuario);
        if (u == null || u.objectId == null) return;
        try {
            Request request = new Request.Builder()
                .url(API_URL + "/" + u.objectId)
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .delete()
                .build();
            OkHttpClient client = new OkHttpClient();
            client.newCall(request).execute();
            System.out.println("Usuario eliminado: " + nombreUsuario);
        } catch (IOException e) {
            System.out.println("Error eliminar usuario: " + e.getMessage());
        }
    }

    @Override
    public Usuario buscarPorUsername(String nombreUsuario) {
        try {
            HttpUrl url = new HttpUrl.Builder()
                .scheme("https")
                .host("parseapi.back4app.com")
                .addPathSegment("classes")
                .addPathSegment("Usuario")
                .addQueryParameter("where", "{\"nombreUsuario\":\"" + nombreUsuario + "\"}")
                .build();
            Request request = new Request.Builder()
                .url(url)
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .get()
                .build();
            OkHttpClient client = new OkHttpClient();
            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                JsonObject body = new Gson().fromJson(response.body().string(), JsonObject.class);
                JsonArray results = body.getAsJsonArray("results");
                if (results.size() > 0) {
                    UsuarioJson j = new Gson().fromJson(results.get(0), UsuarioJson.class);
                    return fromJson(j);
                }
            }
        } catch (IOException e) {
            System.out.println("Error buscar usuario: " + e.getMessage());
        }
        return null;
    }

    @Override
    public ArrayList<Usuario> obtenerTodos() {
        ArrayList<Usuario> lista = new ArrayList<>();
        try {
            Request request = new Request.Builder()
                .url(API_URL)
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .get()
                .build();
            OkHttpClient client = new OkHttpClient();
            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                JsonObject body = new Gson().fromJson(response.body().string(), JsonObject.class);
                JsonArray results = body.getAsJsonArray("results");
                for (JsonElement el : results) {
                    UsuarioJson j = new Gson().fromJson(el, UsuarioJson.class);
                    lista.add(fromJson(j));
                }
            }
        } catch (IOException e) {
            System.out.println("Error obtenerTodos: " + e.getMessage());
        }
        return lista;
    }
}
