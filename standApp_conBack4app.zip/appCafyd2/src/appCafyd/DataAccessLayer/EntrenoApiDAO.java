/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package appCafyd.DataAccessLayer;

import appCafyd.BusinessLogicLayer.Models.Entreno;
import appCafyd.BusinessLogicLayer.Services.IEntreno;
import com.google.gson.*;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import okhttp3.*;

public class EntrenoApiDAO implements IEntreno {
    private final String API_URL = "https://parseapi.back4app.com/classes/Entreno";
    private final String APPLICATION_ID = "efLmzg1LvgF58oqKQ6s0Nw0GizH2ssgul4z8AMUl";
    private final String REST_API_KEY = "ygnqEDUypcFGRm0pRrY8NGjOwgV462OGaBluopie";

    private class EntrenoJson {
        public String objectId;
        public String usuarioId;
        public String fecha;
        public Integer diaReto;
        public Boolean completado;
        public String foto;
        public Integer dificultad;
    }

    private EntrenoJson toJson(Entreno e, String usuarioId) {
        EntrenoJson j = new EntrenoJson();
        j.usuarioId  = usuarioId;
        j.fecha = e.fecha.toString();
        j.diaReto = e.diaReto;
        j.completado = e.completado;
        j.foto = e.foto;
        j.dificultad = e.dificultad;
        return j;
    }

    private Entreno fromJson(EntrenoJson j) {
        Entreno e = new Entreno(LocalDate.parse(j.fecha), j.diaReto);
        e.objectId  = j.objectId;
        e.completado = j.completado;
        e.foto = j.foto;
        e.dificultad = j.dificultad;
        return e;
    }

    @Override
    public void guardar(Entreno entreno) {
        Gson gson = new Gson();
        String json = gson.toJson(toJson(entreno, entreno.usuarioId));
        try {
            Request request = new Request.Builder()
                .url(API_URL)
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .post(RequestBody.create(MediaType.get("application/json"), json))
                .build();
            OkHttpClient client = new OkHttpClient();
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                EntrenoJson nuevo = gson.fromJson(response.body().string(), EntrenoJson.class);
                entreno.objectId = nuevo.objectId;
                System.out.println("Entreno guardado con objectId: " + entreno.objectId);
            }
        } catch (IOException e) {
            System.out.println("Error guardar entreno: " + e.getMessage());
        }
    }

    @Override
    public Entreno buscarPorFecha(LocalDate fecha) {
        // No se usa directamente — los entrenos se buscan por usuario
        return null;
    }

    // Método extra: obtener todos los entrenos de un usuario
    public ArrayList<Entreno> listarPorUsuario(String nombreUsuario) {
        ArrayList<Entreno> lista = new ArrayList<>();
        try {
            HttpUrl url = new HttpUrl.Builder()
                .scheme("https")
                .host("parseapi.back4app.com")
                .addPathSegment("classes")
                .addPathSegment("Entreno")
                .addQueryParameter("where", "{\"usuarioId\":\"" + nombreUsuario + "\"}")
                .build();
            Request request = new Request.Builder()
                .url(url)
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .get()
                .build();
            OkHttpClient client = new OkHttpClient();
            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                JsonObject body = new Gson().fromJson(response.body().string(), JsonObject.class);
                JsonArray results = body.getAsJsonArray("results");
                for (JsonElement el : results) {
                    EntrenoJson j = new Gson().fromJson(el, EntrenoJson.class);
                    lista.add(fromJson(j));
                }
            }
        } catch (IOException e) {
            System.out.println("Error listarPorUsuario: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public ArrayList<Entreno> listarTodos() {
        return new ArrayList<>(); // no necesario en este contexto
    }
}
