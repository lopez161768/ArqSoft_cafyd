/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package appCafyd.Application;

import appCafyd.BusinessLogicLayer.Services.UsuarioService;
import appCafyd.DataAccessLayer.EntrenoApiDAO;
import appCafyd.DataAccessLayer.UsuarioApiDAO;
import appCafyd.PresentationLogicLayer.Presenters.*;
import appCafyd.PresentationLogicLayer.Views.*;

public class Back4AppApplication {
    public static void main(String[] args) {

        // DAOs conectados a Back4App
        UsuarioApiDAO uDao = new UsuarioApiDAO();
        EntrenoApiDAO eDao = new EntrenoApiDAO();

        // Service con las mismas dependencias inyectadas
        UsuarioService service = new UsuarioService(uDao, eDao);

        // Vistas (exactamente igual que ConsoleApplication)
        LoginConsole   loginView   = new LoginConsole();
        InicialConsole inicialView = new InicialConsole();
        EntrenoConsole entrenoView = new EntrenoConsole();
        PerfilConsole  perfilView  = new PerfilConsole();

        // Presenters
        LoginPresenter   loginPresenter   = new LoginPresenter(loginView,   service);
        InicialPresenter inicialPresenter = new InicialPresenter(inicialView, service);
        EntrenoPresenter entrenoPresenter = new EntrenoPresenter(entrenoView, service);
        PerfilPresenter  perfilPresenter  = new PerfilPresenter(perfilView,  service);

        // PresenterManager
        PresenterManager.loginPresenter   = loginPresenter;
        PresenterManager.inicialPresenter = inicialPresenter;
        PresenterManager.entrenoPresenter = entrenoPresenter;
        PresenterManager.perfilPresenter  = perfilPresenter;

        // Arrancar
        loginPresenter.load();
    }
}
